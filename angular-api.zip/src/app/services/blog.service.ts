import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()

export class BlogService {
    constructor(private httpclient: HttpClient) {}
    
    getblogs(): Observable<any> {
        return this.httpclient.get('https://jsonplaceholder.typicode.com/posts');
    }


    getblogsById(id): Observable<any> {
      return this.httpclient.get('https://jsonplaceholder.typicode.com/posts/'+id);
    }

    getblogComments(id): Observable<any> {
      return this.httpclient.get('https://jsonplaceholder.typicode.com/posts/'+id+'/comments');
    }


    deleteBlog(id){
      return this.httpclient.delete('https://jsonplaceholder.typicode.com/posts/'+id);
    }
}