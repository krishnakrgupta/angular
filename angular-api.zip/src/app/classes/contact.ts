export interface ContactForm {
    name: string,
    emailOffers: boolean,
    interfaceStyle: string,
    subscriptionType: string,
    notes:string
}