import { Component, OnInit } from '@angular/core';
import { BlogService } from '../services/blog.service';
import { Blog } from '../classes/blog';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-blogdetails',
  templateUrl: './blogdetails.component.html',
  styleUrls: ['./blogdetails.component.css']
})
export class BlogdetailsComponent implements OnInit {

  blogDetails: Blog[];

  constructor(private _BlogService: BlogService,private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this._BlogService.getblogsById(id)
    .subscribe(
      data=> {
        this.blogDetails = data;
      }
    );
  }

}
