import { Component, OnInit } from '@angular/core';
import { BlogService } from '../services/blog.service';
import { Blog } from '../classes/blog';


@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.css']
})
export class BlogsComponent implements OnInit {
  title = 'rest-api';
  listblogs: Blog[];
  constructor(private _BlogService: BlogService) { }

  ngOnInit() {
    this._BlogService.getblogs()
    .subscribe(
      data=>
      {
        this.listblogs = data;
      }
    );
  }

  deleteBlog(id) {
    this._BlogService.deleteBlog(id).subscribe(
      data=>
      {
        //this.listblogs = data;
        console.log('deleted', data);
      }
      );

  }

}
