import { Component, OnInit } from '@angular/core';
import { BlogService } from '../services/blog.service';
import { Blog } from '../classes/blog';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-blogcomments',
  templateUrl: './blogcomments.component.html',
  styleUrls: ['./blogcomments.component.css']
})
export class BlogcommentsComponent implements OnInit {

  blogComments: Blog[];

  constructor(private _BlogService: BlogService,private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this._BlogService.getblogComments(id)
    .subscribe(
      data=> {
        this.blogComments = data;
      }
    );

  }

}
