import { Component, OnInit } from '@angular/core';
import { ContactForm } from '../classes/contact';
import { NgForm, NgModel } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  contactForm: ContactForm =  {
      name: null,
      emailOffers: null,
      interfaceStyle: null,
      subscriptionType: null,
      notes: null
  }

  usercontactForm: ContactForm = { ...this.contactForm };

  constructor() { }

  ngOnInit() {
  }

  onBlur(field: NgModel){
    console.log('In submit: ', field.valid);
  }

  onSumit(form: NgForm) {
    console.log('In submit: ', form.valid);
  }

}
