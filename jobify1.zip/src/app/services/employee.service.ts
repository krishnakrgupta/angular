import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
  })
  export class EmployeeService {

    constructor(private httpclient: HttpClient) { }

    getemployee(): Observable<any> {
      return this.httpclient.get('http://localhost:3000/employee');
    }

    deleteEmployee(id): Observable<any> {
        return this.httpclient.delete('http://localhost:3000/employee/'+id);
    }
    addEmployee(data): Observable<any> {
      return this.httpclient.post('http://localhost:3000/employee', data);
    }
    updateEmployee(id): Observable<any> {
      return this.httpclient.get('http://localhost:3000/employee/'+id);
    }


  }