import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Login } from '../classes/login';


@Injectable({
    providedIn: 'root'
})

export class LoginApiService {

    constructor(private httpclient: HttpClient) {

    }

    login(email: string, password: string): Observable<any>{
        console.log(email,password);
        return this.httpclient.post<any>('https://reqres.in/api/login', {
          email: email,
          password: password
         }
        );
      }
}