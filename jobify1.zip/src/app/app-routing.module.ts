import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent} from './components/home/home.component';
import { PagesComponent } from './components/pages/pages.component';
import { ContactComponent } from './components/contact/contact.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { BlogsComponent } from './components/blogs/blogs.component';
import { BlogdetailsComponent } from './components/blogdetails/blogdetails.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { AddemployeeComponent } from './components/addemployee/addemployee.component';
import { LoginComponent } from './components/login/login.component';
import { NeedAuthGuard } from './services/NeedAuthGuard';


const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'pages/:id', component: PagesComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'blogs', component: BlogsComponent },
  { path: 'blogs/:id', component: BlogdetailsComponent },
  { path: 'login', component: LoginComponent },
  { path: 'employee', component: EmployeeComponent, canActivate: [NeedAuthGuard] },
  { path: 'employee/add', component: AddemployeeComponent },
  { path: '**', component: PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
