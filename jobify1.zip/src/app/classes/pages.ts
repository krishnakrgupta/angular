export class Pages
{
    id: number;
    title: string;
    body: string;
}