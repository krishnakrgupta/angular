export class Blog
{
    userId: number;
    id: number;
    title: string;
    body: string;
}