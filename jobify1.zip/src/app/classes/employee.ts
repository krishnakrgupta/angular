export class Employee
{
    id: number;
    employee_name: number;
    employee_salary: number;
    employee_age: number;
    profile_image: string;
}