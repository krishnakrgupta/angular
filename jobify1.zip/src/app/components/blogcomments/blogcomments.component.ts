import { Component, OnInit } from '@angular/core';
import { BlogsService } from '../../services/blogs.service';
import { Blog } from '../../classes/blog';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-blogcomments',
  templateUrl: './blogcomments.component.html',
  styleUrls: ['./blogcomments.component.css']
})
export class BlogcommentsComponent implements OnInit {

  blogComments: Blog[];

  constructor(private _BlogsService: BlogsService,private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this._BlogsService.getblogComments(id)
    .subscribe(
      data=> {
        this.blogComments = data;
      }
    );
  }

}
