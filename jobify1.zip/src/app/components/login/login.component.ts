import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';
import { LoginApiService } from '../../services/loginapi.service';
import { CustomerService } from '../../services/customer.service';
import { Login } from '../../classes/login';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;

   email = null;
   password = null;
   showErrorMsg = null;

  constructor( private formBuilder: FormBuilder, private api: LoginApiService,
               private customer: CustomerService, private router: Router) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
    console.log(this.loginForm.value);
    this.email = this.loginForm.value.email;
    this.password = this.loginForm.value.password;
    this.api.login(this.email, this.password).
    subscribe(
      data => {
        if(data.token){
            console.log('called login success', data.token);
            this.customer.setToken(data.token);
            this.router.navigateByUrl('/employee');
        }
      },
      data => {
        console.log('called login error', data.error.error);
        this.showErrorMsg = data.error.error;
      }
    )
  }
}
