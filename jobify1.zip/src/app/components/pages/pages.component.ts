import { Component, OnInit } from '@angular/core';
import { PagesService } from '../../services/pages.service';
import { Pages } from '../../classes/pages';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.css']
})
export class PagesComponent implements OnInit {
  title = 'About Us';
  listpages: Pages[];
  constructor(private _PagesService: PagesService, private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this._PagesService.getpages(id)
    .subscribe(
      data => {
        this.listpages = data;
      }
    );
  }

  /*showPageContent(id){
    this._PagesService.getpages(id)
    .subscribe(
      data => {
        this.listpages = data;
      }
    );
  }*/

}
