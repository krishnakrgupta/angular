import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../classes/employee';
import { NgForm, NgModel } from '@angular/forms';
import {Router} from "@angular/router";

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  title = 'Add Employee';
  showMsg = false;
  EmployeeForm: Employee = {
    id: null,
    employee_name: null,
    employee_salary: null,
    employee_age: null,
    profile_image: null
  };

  constructor(private _EmployeeService: EmployeeService, private router: Router) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm){


    this._EmployeeService.addEmployee(this.EmployeeForm)
    .subscribe(
      (data) => {
        console.log("add call data",data);
        this.router.navigate(['/employee']);
        this.showMsg = true;
      },
      response => {
        console.log('add call in error', response);
      }
    );

    console.log('in',this.EmployeeForm);
  }
}
