import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../classes/employee';
import { NgxSpinnerService } from "ngx-spinner";


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  title = 'Blogs';
  showMsg: boolean = false;
  showForm = false;
  showListData = true;
  p: number = 1;
  listemployee: Employee[];

  constructor(private _EmployeeService: EmployeeService, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.spinner.show();
    this.getemployee();
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

  }

  getemployee(){
    this._EmployeeService.getemployee()
    .subscribe(
      data =>{
        this.listemployee = data;
      },
      response => {
        console.log("Get call in error", response);
      }
    );
  }

  onDeleteEmployee(id) {
    //alert(id);
    this._EmployeeService.deleteEmployee(id)
    .subscribe(
      (id) => {
        console.log('DELETE call', id);
        this.getemployee();
        this.showMsg = true;
      },
      response => {
        console.log('DELETE call in error', response);
      }
    );

    this.spinner.show();
    setTimeout(() => {
      /** spinner ends after 5 seconds */
      this.spinner.hide();
    }, 1000);

  }

  onUpdateEmployee(id) {
    this.showForm = true;
    this.showListData = false;

    this._EmployeeService.updateEmployee(id)
    .subscribe(
      data => {
        console.log('Data call', data);
        this.listemployee = data;
        this.showMsg = false;
      },
      response => {
        console.log('Get call in error', response);
      }
    );

  }


  cancelUpdate(){
    this.showForm = false;
    this.showListData = true;
    this.getemployee();
  }

}
