import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PagesComponent } from './components/pages/pages.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContactComponent } from './components/contact/contact.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { BlogsComponent } from './components/blogs/blogs.component';
import { BlogsService } from './services/blogs.service';
import { EmployeeService } from './services/employee.service';
import { PagesService } from './services/pages.service';
import { BlogdetailsComponent } from './components/blogdetails/blogdetails.component';
import { BlogcommentsComponent } from './components/blogcomments/blogcomments.component';
import { EmployeeComponent } from './components/employee/employee.component';
import { AddemployeeComponent } from './components/addemployee/addemployee.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { LoginComponent } from './components/login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginApiService } from './services/loginapi.service';
import { CustomerService } from './services/customer.service';
import { NeedAuthGuard } from './services/NeedAuthGuard';



@NgModule({
  declarations: [
    AppComponent,
    PagesComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ContactComponent,
    PageNotFoundComponent,
    BlogsComponent,
    BlogdetailsComponent,
    BlogcommentsComponent,
    EmployeeComponent,
    AddemployeeComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    NgxSpinnerModule,
    AppRoutingModule
  ],
  providers: [BlogsService, EmployeeService, PagesService, LoginApiService, CustomerService, NeedAuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
