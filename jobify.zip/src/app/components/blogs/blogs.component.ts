import { Component, OnInit } from '@angular/core';
import { BlogsService } from '../../services/blogs.service';
import { Blog } from '../../classes/blog';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.css']
})
export class BlogsComponent implements OnInit {
  title = 'Blogs';
  p: number = 1;
  listblogs: Blog[];
  constructor(private _BlogsService: BlogsService) { }

  ngOnInit() {
    this._BlogsService.getblogs()
    .subscribe(
      data=>
      {
        this.listblogs = data;
      }
    );
  }


}
