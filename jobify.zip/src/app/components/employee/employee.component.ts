import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../../services/employee.service';
import { Employee } from '../../classes/employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  title = 'Blogs';
  p: number = 1;
  listemployee: Employee[];

  constructor(private _EmployeeService: EmployeeService) { }

  ngOnInit() {
    this._EmployeeService.getemployee()
    .subscribe(
      data =>{
        this.listemployee = data;
      },
      response => {
        console.log("Get call in error", response);
      }
    );

  }

  onDeleteEmployee(id){
    alert(id);
    this._EmployeeService.deleteEmployee(id)
    .subscribe(
      () => {
        console.log("DELETE call in error");
      },
      response => {
        console.log('DELETE call in error', response);
      }
    );
  }

}
