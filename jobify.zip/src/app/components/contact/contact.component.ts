import { Component, OnInit } from '@angular/core';
import { ContactForm } from '../../classes/contact';
import { NgForm, NgModel } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  title = 'Contact Us';
  contactForm: ContactForm = {
    name: null,
    email: null,
    phone: null,
    message: null
  };

  usercontactForm: ContactForm = { ...this.contactForm };

  constructor() { }

  ngOnInit() {
  }

  onBlur(field: NgModel){
    console.log('In submit: ', field.valid);
  }
  
  onSubmit(form: NgForm) {
    //alert('sdfsdf');
    console.log(this.contactForm);
    console.log('In Submit', form.valid);
    //TODO send email API call
  }

}
