import { Component, OnInit } from '@angular/core';
import { BlogsService } from '../../services/blogs.service';
import { Blog } from '../../classes/blog';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-blogdetails',
  templateUrl: './blogdetails.component.html',
  styleUrls: ['./blogdetails.component.css']
})
export class BlogdetailsComponent implements OnInit {

  blogDetails: Blog[];

  constructor(private _BlogsService: BlogsService, private route: ActivatedRoute) { }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this._BlogsService.getblogsById(id)
    .subscribe(
      data=> {
        this.blogDetails = data;
      }
    );
  }

}
