import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {NgxPaginationModule} from 'ngx-pagination'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PagesComponent } from './components/pages/pages.component';
import { HomeComponent } from './components/home/home.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { ContactComponent } from './components/contact/contact.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { BlogsComponent } from './components/blogs/blogs.component';
import { BlogsService } from './services/blogs.service';
import { EmployeeService } from './services/employee.service';
import { BlogdetailsComponent } from './components/blogdetails/blogdetails.component';
import { BlogcommentsComponent } from './components/blogcomments/blogcomments.component';
import { EmployeeComponent } from './components/employee/employee.component';



@NgModule({
  declarations: [
    AppComponent,
    PagesComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    ContactComponent,
    PageNotFoundComponent,
    BlogsComponent,
    BlogdetailsComponent,
    BlogcommentsComponent,
    EmployeeComponent,
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    NgxPaginationModule,
    AppRoutingModule
  ],
  providers: [BlogsService, EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
