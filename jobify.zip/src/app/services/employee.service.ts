import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
    providedIn: 'root'
  })
  export class EmployeeService {

    constructor(private httpclient: HttpClient) { }

    getemployee(): Observable<any> {
      return this.httpclient.get('http://dummy.restapiexample.com/api/v1/employees');
    }

    deleteEmployee(id): Observable<any> {
        return this.httpclient.delete('http://dummy.restapiexample.com/api/v1/update/'+id);
      }
  }