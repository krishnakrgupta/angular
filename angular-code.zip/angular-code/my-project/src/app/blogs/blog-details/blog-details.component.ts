import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-blog-details',
  templateUrl: './blog-details.component.html',
  styleUrls: ['./blog-details.component.css']
})
export class BlogDetailsComponent implements OnInit {

  title = 'Blog';
  restItems: any;
  restItemsUrl = 'https://jsonplaceholder.typicode.com/posts';
  
  
  constructor(private route: ActivatedRoute,private router: Router,private http: HttpClient) { }

  ngOnInit() {
	  let id = this.route.snapshot.paramMap.get('id');
	  this.getRestItems(id);
  }

  	// Read all REST Items
  getRestItems(id): void {
    this.restItemsServiceGetRestItems(id)
      .subscribe(
        restItems => {
          this.restItems = restItems;
          console.log(this.restItems);
        }
      )
  }

  // Rest Items Service: Read all REST Items
  restItemsServiceGetRestItems(id) {
	let details = this.restItemsUrl+"/"+id;
    return this.http
      .get<any[]>(details)
      .pipe(map(data => data));
  }
  
}
