import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ListUsersComponent } from './users/list-users/list-users.component';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateUsersComponent } from './users/create-users/create-users.component';
import {NgxPaginationModule} from 'ngx-pagination';

@NgModule({
  declarations: [
    AppComponent,
    ListUsersComponent,
    CreateUsersComponent,
  ],
  imports: [
    BrowserModule,
      FormsModule,
      HttpModule,
      ReactiveFormsModule,
      NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
