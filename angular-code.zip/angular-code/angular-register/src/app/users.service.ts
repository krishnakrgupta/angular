import { Injectable } from '@angular/core';
import { Http, Response,Headers, RequestOptions } from '@angular/http';
import { Observable} from 'rxjs';
import { Users } from './users';
import { map } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class UsersService {
 
  // We need Http to talk to a remote server.
  constructor(private _http : Http){ }

  // Get list of products from remote server.
  readUsers(): Observable<Users[]>{

      return this._http
          .get("http://localhost/api/read.php")
          .pipe(map((res: Response) => res.json()));
  }

  // Send product data to remote server to create it.
  createUsers(users): Observable<Users>{
 
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    return this._http.post(
        "http://localhost/api/create.php",
        users,
        options
    ).pipe(map((res: Response) => res.json()));
  }

}
