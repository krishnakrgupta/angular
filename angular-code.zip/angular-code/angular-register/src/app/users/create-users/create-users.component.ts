import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { UsersService } from '../../users.service';
import { Users } from '../../users';


@Component({
  selector: 'app-create-users',
  templateUrl: './create-users.component.html',
  styleUrls: ['./create-users.component.css'],
  providers: [UsersService]
})
export class CreateUsersComponent implements OnInit {

  // store list of users
  users: Users[];
  // our angular form
  create_product_form: FormGroup;
  // @Output will tell the parent component (AppComponent) that an event happened in this component
  @Output() show_read_products_event = new EventEmitter();

  constructor(private UsersService: UsersService,formBuilder: FormBuilder) {

     // based on our html form, build our angular form
     this.create_product_form = formBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.required]
    });

   }

  // user clicks 'create' button
  createUsers(){
    
    // send data to server
    this.UsersService.createUsers(this.create_product_form.value)
        .subscribe(
             Users => {
                // show an alert to tell the user if product was created or not
                console.log(Users);

                // go back to list of products
                this.readUsers();
             },
             error => console.log(error)
         );
  }

  // user clicks the 'read products' button
  readUsers(){
    //this.show_read_products_event.emit({ title: "Read Products" });
  }

  ngOnInit() {
  }

}
