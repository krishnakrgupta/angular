import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../users.service';
import { Users } from '../../users';


@Component({
  selector: 'app-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.css'],
  providers: [UsersService]
})
export class ListUsersComponent implements OnInit {

  
  // store list of users
  users: Users[];
 
  // initialize productService to retrieve list users in the ngOnInit()
  constructor(private usersService: UsersService){}

  // methods that we will use later
  //createUsers(){ }
  readOneProduct(){}
  updateProduct(){}
  deleteProduct(){}

  // Read users from API.
  ngOnInit(){
      this.usersService.readUsers()
          .subscribe(users =>
              this.users = users,
            
          );
          console.log(this.users);
          
  }

}
