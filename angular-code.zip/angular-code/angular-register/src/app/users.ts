export class Users {
    constructor(
        public firstname: string,
        public lastname: string
    ) { }
}
